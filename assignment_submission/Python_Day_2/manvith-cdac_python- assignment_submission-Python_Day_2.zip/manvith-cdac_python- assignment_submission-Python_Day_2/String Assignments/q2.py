text = input("Enter a string: ")

start = int(input("Enter start position: "))
end = int(input("Enter end position: "))

print("Sliced String:", text[start:end])