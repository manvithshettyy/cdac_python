text = input("Enter a string: ")

words = text.split()

print("Number of words:", len(words))