list1 = [x for x in range(1, 21)]

odd_list = [x for x in list1 if x % 2 != 0]

print("All Numbers:", list1)
print("Odd Numbers:", odd_list)