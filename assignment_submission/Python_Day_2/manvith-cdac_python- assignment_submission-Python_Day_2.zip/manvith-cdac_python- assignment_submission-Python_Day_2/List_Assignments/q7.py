mylist = ["hello", 123, 'A', True, 3.14]

print("Original List:", mylist)
print("a) Reversed List:", mylist[::-1])
print("b) From 2nd position:", mylist[1:])
print("c) 1st to 3rd position:", mylist[0:3])
print("d) 1st to 3rd from end:", mylist[-3:-1])