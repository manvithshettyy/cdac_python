d = {}
print("Empty" if not d else "Not empty")