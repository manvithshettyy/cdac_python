from collections import Counter
s = 'w3resource'
d = dict(Counter(s))
print(d)