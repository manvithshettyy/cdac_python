d = {1: 'a', 2: 'b', 3: 'c'}
d.pop(2)
print(d)