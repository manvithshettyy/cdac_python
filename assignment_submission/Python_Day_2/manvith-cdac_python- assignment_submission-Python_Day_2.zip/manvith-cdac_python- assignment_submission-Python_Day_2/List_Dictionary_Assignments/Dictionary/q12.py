prnnos = [1, 2, 3, 4, 5, 6]
names = ['abc', 'def', 'pqr', 'lmn', 'xyz', 'uvw']
d = dict(zip(prnnos, names))
print(d)