d = {1: 200, 2: 500, 3: 100}
print("Max:", max(d.values()))
print("Min:", min(d.values()))