d = {0: 10, 1: 20}
key = 1
print(key in d)