d = {1: 'xyz', 3: 'abc', 5: 'pqr', 2: 'xzz'}
print("Keys:", list(d.keys()))
print("Values:", list(d.values()))
print("Items:", list(d.items()))
print("Total items:", len(d))