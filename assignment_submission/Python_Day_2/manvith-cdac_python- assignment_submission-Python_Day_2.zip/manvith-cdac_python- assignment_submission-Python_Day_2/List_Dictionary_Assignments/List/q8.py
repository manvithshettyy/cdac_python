items = ['a', 'b', 'c', 'd']
for index, value in enumerate(items):
    print(f"Index {index}: {value}")