nums = [1, 2, 2, 3, 4, 4, 5]
unique = list(set(nums))
print("Without duplicates:", unique)