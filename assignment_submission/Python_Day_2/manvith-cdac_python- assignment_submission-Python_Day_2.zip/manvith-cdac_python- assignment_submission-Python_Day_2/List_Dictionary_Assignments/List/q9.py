lst = []
if not lst:
    print("List is empty")
else:
    print("List is not empty")