original = [1, 2, 3, 4]
copy_list = original.copy()
print("Cloned list:", copy_list)