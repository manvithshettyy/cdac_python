nums = [5, 2, 99, 13, 72, 1]
print("Largest number is:", max(nums))