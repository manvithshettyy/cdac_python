nums = [1, 2, 3, 4]
product = 1
for num in nums:
    product *= num
print("Product:", product)