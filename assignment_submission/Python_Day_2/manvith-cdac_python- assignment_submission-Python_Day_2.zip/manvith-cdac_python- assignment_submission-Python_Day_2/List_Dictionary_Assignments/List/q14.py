lst = [1, 2, 3, 4]
prefix = 'emp'
result = [prefix + str(x) for x in lst]
print(result)