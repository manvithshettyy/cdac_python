a = [1, 3, 5, 7, 9, 10]
b = [2, 4, 6, 8]
a[-1:] = b
print("Modified list:", a)